const { expect } = require('chai');

// A simple test to check if a question is generated correctly
describe('Math Quiz Tests', () => {
    it('should generate a valid math question', () => {
        const question = generateQuestion(); // Use your function to generate the question
        expect(question).to.have.property('question');
        expect(question).to.have.property('answer');
    });

    it('should detect a correct answer', () => {
        const question = { answer: 5 }; // Example question
        expect(checkAnswer(question, 5)).to.be.true;
    });

    it('should detect an incorrect answer', () => {
        const question = { answer: 5 }; // Example question
        expect(checkAnswer(question, 3)).to.be.false;
    });
});