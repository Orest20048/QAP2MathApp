const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.use(express.static('public'));

// In-memory data storage
let currentQuestion = {};  // Ensure mutability with let
let userStreak = 0;
let leaderboards = [];

// Function to generate a new math question
function generateQuestion() {
    const operations = ['+', '-', '*', '/'];
    let num1 = Math.floor(Math.random() * 10) + 1;  // Use let for mutable variables
    let num2 = Math.floor(Math.random() * 10) + 1;
    const operation = operations[Math.floor(Math.random() * operations.length)];
    let answer;  // Use let since answer will be reassigned

    // Handle division carefully to avoid fractions
    if (operation === '/') {
        answer = num1;  // Ensure no decimal answers
        num1 *= num2;   // Make num1 a multiple of num2
    } else {
        answer = eval(`${num1} ${operation} ${num2}`);
    }

    currentQuestion = { question: `${num1} ${operation} ${num2}`, answer };
}

// Routes
app.get('/', (req, res) => {
    res.render('home', { streak: userStreak });
});

app.post('/start-quiz', (req, res) => {
    userStreak = 0;  // Reset streak for a new quiz
    generateQuestion();  // Generate the first question
    res.redirect('/quiz');
});

app.get('/quiz', (req, res) => {
    res.render('quiz', { question: currentQuestion.question });
});

app.post('/submit-answer', (req, res) => {
    const userAnswer = Number(req.body.answer);
    if (Number.isNaN(userAnswer)) {
        return res.redirect('/quiz?error=Invalid input');  // Error handling for invalid input
    }

    if (userAnswer === currentQuestion.answer) {
        userStreak++;
        generateQuestion();  // Generate a new question for the next round
        res.redirect('/quiz');
    } else {
        leaderboards.push({ streak: userStreak, date: new Date() });
        userStreak = 0;  // Reset streak
        res.redirect('/completion');
    }
});

app.get('/completion', (req, res) => {
    res.render('completion', { streak: userStreak });
});

app.get('/leaderboards', (req, res) => {
    const topScores = leaderboards
        .sort((a, b) => b.streak - a.streak)
        .slice(0, 10);  // Get top 10 scores
    res.render('leaderboards', { scores: topScores });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});
